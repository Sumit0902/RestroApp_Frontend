
const EditCompany = () => {
  return (
    <div>EditCompany</div>
  )
}

export default EditCompany
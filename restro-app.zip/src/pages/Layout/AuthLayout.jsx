
const AuthLayout = ({ children }) => {
    return (
        <div className="full-width auth-layout">{children}</div>
    )
}

export default AuthLayout